const express = require('express');
const router = express.Router();

router.get('/api', (req, res) => {
    res.send('Welcome to the Doujin API!');
});


module.exports = router;